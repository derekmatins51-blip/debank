@extends('layouts.dash2')

@section('title', $title)

@section('content')
    @include('partials.international.method-selection')
@endsection
