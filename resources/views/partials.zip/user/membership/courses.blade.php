@extends('layouts.dash')
@section('title', $title)
@section('content')
    <livewire:user.system-courses />
@endsection
